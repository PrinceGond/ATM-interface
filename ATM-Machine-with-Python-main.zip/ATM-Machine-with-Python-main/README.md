# ATM-Machine-with-Python
1st project with Python. Writing Python codes that mimics an ATM machine function for — password creation, cash deposit, cash withdrawal, view customer transaction history, search customer profile and create customer profile.

For information about this project, please visit: https://medium.com/analytics-vidhya/atm-machine-with-python-d90b9ee300e
